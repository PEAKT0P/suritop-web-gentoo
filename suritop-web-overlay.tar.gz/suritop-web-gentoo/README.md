# suritop-web — Security Monitoring System for Gentoo Linux

## Описание

suritop-web — система мониторинга безопасности для Gentoo Linux:
- **Suricata IDS/IPS** — обнаружение вторжений
- **ModSecurity WAF** — защита веб-приложений
- **Fail2Ban** — блокировка атак
- **iptables** — файрвол с веб-управлением
- **Attack Map** — карта атак в реальном времени
- **Admin Stats** — статистика и мониторинг

## Быстрая установка на чистый Gentoo + OpenRC

### 1. Добавить оверлей

```bash
emerge -av app-eselect/eselect-repository
eselect repository add suritop-web git https://github.com/PEAKT0P/suritop-web-gentoo.git
emerge --sync
```

### 2. Настроить USE flags

```bash
# Принять ключи для пакетов
mkdir -p /etc/portage/package.accept_keywords
cat > /etc/portage/package.accept_keywords/suritop-web << 'EOF'
net-analyzer/suritop-web **
net-analyzer/suricata **
net-libs/libhtp **
EOF

# Настроить USE flags
cat > /etc/portage/package.use/suritop-web << 'EOF'
net-analyzer/suritop-web -iptables -nat -docker +suricata
EOF
```

### 3. Установить пакет

```bash
# Сначала установить зависимости
emerge -av --backtrack=30 net-analyzer/suritop-web

# Интерактивная настройка (nginx, БД, fail2ban, iptables)
emerge --config net-analyzer/suritop-web
```

### 4. Запуск

После `emerge --config` все сервисы уже запущены и добавлены в автозагрузку.

Если нужно запустить вручную:

```bash
rc-service mysql start
rc-service nginx start
rc-service php-fpm start
rc-service suritop-stats start
rc-service suritop-suri start
rc-service suritop-waf start
rc-service iptables-manager start
rc-service suricata start
rc-service fail2ban start
```

Автозагрузка уже настроена через `emerge --config` (вопрос в конце).

## USE Flags

| Flag | По умолчанию | Описание |
|------|-------------|----------|
| `+iptables` | вкл | Автогенерация iptables правил |
| `-nat` | выкл | NAT masquerade (для раздачи интернета) |
| `-docker` | выкл | Интеграция с Docker (DOCKER-USER chain) |
| `+suricata` | вкл | IPS правила Suricata |
| `-geoip` | выкл | GeoIP определение |

## Конфигурация

При `emerge --config` все параметры определяются автоматически:
- **IP сервера** — через `ip route`
- **Интерфейс** — через `ip -o route get 1.1.1.1`
- **SSH порт** — из `/etc/ssh/sshd_config`
- **MariaDB** — запускается и настраивается автоматически
- **Сервисы** — добавляются в автозагрузку

### /etc/conf.d/suritop-web (пример)

```bash
# Автоматическая настройка iptables при загрузке
SURITOP_AUTO_IPTABLES="no"

# Сеть (заполняется автоматически)
SURITOP_SERVER_IP="192.168.1.100"        # авто: ip route
SURITOP_NET_INTERFACE="enp3s0"           # авто: ip -o route
SURITOP_SSH_PORT="22"                    # авто: sshd_config

# Whitelist IP (добавьте ваш IP)
SURITOP_WHITELIST_IP="192.168.1.100"

# БД (пароли для коллекторов)
SURITOP_DB_USER_R="stats_reader"
SURITOP_DB_PASS_R="suritop_read_2026"
SURITOP_DB_USER_W="stats_writer"
SURITOP_DB_PASS_W="suritop_write_2026"

# NAT (для раздачи интернета)
SURITOP_NAT_ENABLE="no"

# Docker
SURITOP_DOCKER_ENABLE="no"
```

## Структура файлов

```
/etc/conf.d/suritop-web          — Конфигурация
/etc/suritop-web/                — Конфиги suricata
/etc/nginx/vhosts.d/suritop-web.conf — Nginx vhost
/opt/stats_collector/            — Python коллекторы
/opt/iptables-manager/           — iptables API daemon
/var/www/suritop-web/htdocs/     — PHP файлы сайта
/usr/share/suritop-web/schema.sql — Схема БД
/etc/init.d/suritop-*            — Init scripts
```

## Доступ

- **URL:** http://server-ip/
- **Логин:** admin
- **Пароль:** admin

## Сервисы

| Сервис | Команда | Описание |
|--------|---------|----------|
| mysql | `rc-service mysql start` | MariaDB база данных |
| nginx | `rc-service nginx start` | Веб-сервер |
| php-fpm | `rc-service php-fpm start` | PHP процессор |
| suritop-stats | `rc-service suritop-stats start` | Сбор метрик системы |
| suritop-suri | `rc-service suritop-suri start` | Коллектор suricata (Attack Map) |
| suritop-waf | `rc-service suritop-waf start` | Коллектор modsecurity |
| iptables-manager | `rc-service iptables-manager start` | API управления файрволом |
| suricata | `rc-service suricata start` | IDS/IPS движок |
| fail2ban | `rc-service fail2ban start` | Блокировка атак |
| iptables | `rc-service iptables start` | Файрвол |

## Удаление

```bash
emerge -C net-analyzer/suritop-web
eselect repository remove suritop-web
rm -rf /etc/suritop-web
rm -rf /var/www/suritop-web
rm -rf /opt/stats_collector
rm -rf /opt/iptables-manager
```
